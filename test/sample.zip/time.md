# Beginning

Some 100 years in the future

# Preliminaries

+100 days

# Main story
+1 year

# End
+3 years

