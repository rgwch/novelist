---
name: Brutus Allerdice
nicknames: 
    Brutus
    Allerdice
    Brute
    Commander
---

Brutus is the commander of the evil force

